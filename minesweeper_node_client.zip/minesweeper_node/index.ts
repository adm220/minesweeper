/* Created just for funcional test purpose */

import "./src/clients/minesweeperClient"
import axios, {AxiosStatic} from "axios"
import { MinesweeperClient } from "./src/clients/minesweeperClient"
import { Level } from "./src/model/payloads";

const client = new MinesweeperClient("8946fbf3-7b07-4dbd-8cc6-4dd3455ae3b1","http://localhost:8080");

client.newGame(Level.EASY).then((response) => console.log(response.data.field));
client.flag(0,0).then((response) => console.log(response.data.field[0][0]));
client.questionMark(0,1).then((response) => console.log(response.data.field[0][1]));
client.play(0,2).then((response) => console.log(response.data.field[0][2]));
client.resumeGame().then((response) => console.log(response.data.endTime));
