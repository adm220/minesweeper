import axios, { AxiosResponse }  from "axios"
import { BoardResponse, Level } from "../model/payloads"
import '../model/payloads.ts'


export class MinesweeperClient{

    request = axios.create({
        timeout: 2000
      });
    constructor(protected apikey: string, protected basePath: string){}

    public async resumeGame(): Promise<AxiosResponse<BoardResponse>>{
        
        return this.request.get<BoardResponse>(`${this.basePath}/minesweeper/v1/game`,
        {
            headers:{"x-api-key": this.apikey},
        }).catch(function (error) {
            
            console.log(error.response.data);
            return error.toJSON();
          });
    }


    // public async flag(apikey: String, basePath: String, row: number, column: number): Promise<{}>{
        
    //     return this.request.get<BoardResponse>(`${basePath}/minesweeper/v1/game`)
    // }

    // public async questionMark(apikey: String, basePath: String, row: number, column: number): Promise<{}>{
        
    //     return this.request.get<BoardResponse>(`${basePath}/minesweeper/v1/game`)
    // }

   

    public async newGame(level: Level): Promise<AxiosResponse<BoardResponse>>{        
    
    return this.request.post<BoardResponse>(`${this.basePath}/minesweeper/v1/game`, {'level': level},{

        headers:{"x-api-key": this.apikey}

    }).catch(function (error) {        
        console.log(error.response.data);
        return error.toJSON();
        });
    }

    public async play( row: number, column: number): Promise<AxiosResponse<BoardResponse>>{        
    
    return this.request.put<BoardResponse>(`${this.basePath}/minesweeper/v1/game/play`, {'row': row, 'column': column},{

        headers:{"x-api-key": this.apikey}

    }).catch(function (error) {        
        console.log(error.response.data);
        return error.toJSON();
        });
    }

    public async questionMark( row: number, column: number): Promise<AxiosResponse<BoardResponse>>{        

    return this.request.put<BoardResponse>(`${this.basePath}/minesweeper/v1/game/question`, {'row': row, 'column': column},{

        headers:{"x-api-key": this.apikey}

    }).catch(function (error) {        
        console.log(error.response.data);
        return error.toJSON();
        });
    }

    public async flag( row: number, column: number): Promise<AxiosResponse<BoardResponse>>{        

    return this.request.put<BoardResponse>(`${this.basePath}/minesweeper/v1/game/flag`, {'row': row, 'column': column},{

        headers:{"x-api-key": this.apikey}

    }).catch(function (error) {        
        console.log(error.response.data);
        return error.toJSON();
        });
    }
}