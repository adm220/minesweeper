export enum Level{
    EASY ="EASY",
    MEDIUM="MEDIUM",
    HARD="HARD",
}
export interface BoardRequest{

    level: Level
}

export interface Cell{
    revealed: boolean
    mine: boolean
    flag: boolean
    questionMark: boolean
    minesAroud: number
}

export interface BoardResponse{
    username: string
    state: string
    field: Cell
    startTime: Date
    endTime: Date

}

export interface ErrorResponse{
    errorMessage: string
}

export interface PlayRequest{

    row: number
    column: number

}

